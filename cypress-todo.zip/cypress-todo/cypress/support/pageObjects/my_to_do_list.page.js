/// <reference types="cypress" />

export class MyToDoListPage {
    openMyToDoListPage() {
        cy.visit('/');
    };

    validateMyToDoListPage() {
        //validate the page title
        cy.xpath('//div[@id="main"]/h1').should('have.text', 'My Todo list');

        //validate url is localhost:3000
        cy.url().should('include', 'localhost:3000');
    }

    addNewItem(item) {
        //enter new todo item
        cy.get('input[data-cy="newItemField"]').type('Pay Bills');

        //click add button
        cy.get('#addBtn', {timeout: 1000}).click({force: true});
        // cy.get('button[id="addBtn"]').click({force: true});
        // cy.wait(1000);
    };

    validateToDoListContains(item) {
        //validate the new item is added to the list
        cy.xpath('//table/tbody/tr/td').should('contain.text', item);
    }

    tickItem(item) {
        //tick the item that contains "Fill Gas"
        cy.get('table.pure-table.pure-table-horizontal tbody tr[data-cy="todoItem"]')
          .contains('td.undone', item)
          .within(() => {
              cy.get('span[data-cy="markAsCompleted"]').click();
          });

        //   cy.wait(1000);
        // cy.xpath('//table/tbody/tr/td').contains('Fill Gas').parent().find('input[type="checkbox"]').check();


        // //validate the new item is added to the list
        // cy.xpath('//table/tbody/tr/td').should('contain.text', item);
    }

    validateItemIsCompleted(item) {
        //validate the item has a class of "done"
        cy.get('table[class="pure-table pure-table-horizontal"] tr[data-cy="todoItem"]')
          .contains('td.done', item);

        // cy.get('table.pure-table.pure-table-horizontal tbody tr[data-cy="todoItem"]')
        //   .contains('td.done', item);
    }

    deleteItem(item) {
        //delete the item that contains item
        cy.get('table[class="pure-table pure-table-horizontal"] tr[data-cy="todoItem"]')
          .contains('td', item)
          .parent()
          .within(() => {
              cy.get('span[data-cy="markAsDeleted"]').click();
          });
    }

    validateItemWasDeleted(item) {
        //validate the table has a length of 2
        cy.get('table[class="pure-table pure-table-horizontal"] tr[data-cy="todoItem"]').should('have.length', 2);

        //validate the item was deleted
        cy.get('table[class="pure-table pure-table-horizontal"] tr[data-cy="todoItem"]')
          .contains('td', item)
          .should('not.exist');
    }

}