const { defineConfig } = require('cypress')

module.exports = defineConfig({
  reporter: 'cypress-mochawesome-reporter',
  // reporter: 'mochawesome',
  // reporterOptions: {
  //   reportDir: 'cypress/reports',
  //   overwrite: false,
  //   html: false,
  //   json: true
  // },
  e2e: {
    // We've imported your old cypress plugins here.
    // You may want to clean this up later by importing these.
    setupNodeEvents(on, config) {
      // implement node event listeners here
      require('cypress-mochawesome-reporter/plugin')(on);
      // require('./cypress/plugins/index.js')(on, config)
      // return config;
      return require('./cypress/plugins/index.js')(on, config)
    },
    baseUrl: 'http://localhost:3000',

    // Command timeout overridden for E2E tests
    pageLoadTimeout: 40000,
    defaultCommandTimeout: 30_000,
  },
  // e2e: {
  //   // We've imported your old cypress plugins here.
  //   // You may want to clean this up later by importing these.
  //   setupNodeEvents(on, config) {
  //     return require('./cypress/plugins/index.js')(on, config)
  //   },
  //   baseUrl: 'http://localhost:3000',

  //   // Command timeout overridden for E2E tests
  //   pageLoadTimeout: 40000,
  //   defaultCommandTimeout: 30_000,
  // },
})
